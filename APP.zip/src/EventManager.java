// Location: Desktop/projects/Event_Tracker/src/EventManager.java

import java.util.ArrayList;
import java.util.List;
import java.time.LocalDate;

public class EventManager {
    private List<Event> events;

    public EventManager() {
        events = new ArrayList<>();
    }

    public void addEvent(Event event) {
        events.add(event);
    }

    public void displayReminders() {
        System.out.println("Checking reminders..."); // Add this line to confirm method execution
        LocalDate today = LocalDate.now();
        for (Event event : events) {
            System.out.println("Event Date: " + event.getDate()); // Print event dates
            if (event.getDate().isEqual(today)) {
                System.out.println(event.getReminderMessage());
                System.out.println("YOOOO");
            }
        }
    }
    
}
