// Location: Desktop/projects/Event_Tracker/src/EventTrackerApp.java

import java.time.LocalDate;

public class EventTrackerApp {
    public static void main(String[] args) {
        System.out.println("Program started");
        EventManager eventManager = new EventManager();
        System.out.println("EventManager created");
    
        // Sample events
        eventManager.addEvent(new Birthday("Alice", LocalDate.of(2023, 11, 5), 25));
        eventManager.addEvent(new Anniversary("John and Jane", LocalDate.of(2023, 11, 5), "wedding"));
        eventManager.addEvent(new GeneralEvent("Project Deadline", LocalDate.of(2023, 11, 5), "work"));
        // Add a sample event for today's date
        eventManager.addEvent(new Birthday("Test Event", LocalDate.now(), 25));
    
        // Display reminders for today's events
        eventManager.displayReminders();
        System.out.println("displayReminders called");
    }
    
}
